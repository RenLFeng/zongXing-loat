export default myqcloudConfig = {
  appid:'1254600850',
  bucket: 'shuke',
  sid: 'AKIDVcbL6vdP3Zx85pltBF6pgQCsVWO7qbZW',
  skey: '892umcR7XllgVEm9Qgw631qVxOegU4QX',
  region: 'sh',//地域信息 必填参数 华南地区填gz 华东填sh 华北填tj
};


