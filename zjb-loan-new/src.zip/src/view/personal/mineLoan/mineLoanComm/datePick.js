/*
 * @Author: wfl 
 * @Date: 2018-07-05 18:47:22 
 * @Last Modified by: wfl
 * @Last Modified time: 2018-07-06 10:23:39
 */
import React from 'react';
import {Select} from 'antd';
const Option = Select.Option;
const year = ['2018','2019','2020'];
const Month = ['1','2','3'];
const Day = ['1','2','3'];

export default class DatePick extends React.Component{
    constructor(props){
        super(props);
        this.state = {

        }
    }
    render(){
        return(
            <div>

            </div>
        )
    }
}