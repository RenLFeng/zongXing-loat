import store from './index';

export default function onErrorHandle(err, dispatch) {
  
  console.log(err);
  console.log(dispatch);
}